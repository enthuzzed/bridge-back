export enum ContractKey {
  PolygonBridge = 'polygonBridgeContract',
  PolygonToken = 'polygonTokenContract',
  DfinityBridge = 'dfinityBridgeContract',
  DfinityToken = 'dfinityTokenContract',
}
