export interface IIdentifier {
  index?: number,
  hash?: string
}

export interface IOperation {
  operation_identifier: IIdentifier,
  type: string,
  status: string,
  account: IAccount,
  amount: IAmount
}

export interface IAccount {
  address: string
}

export interface IAmount {
  value: string,
  currency: {
    symbol: string,
    decimals: number
  }
}

export interface IMetadata {
  block_height: number,
  memo: number,
  timestamp: number
}

export interface ITransaction{
  transaction_identifier: IIdentifier,
  operations: IOperation[],
  metadata: IMetadata
}

export interface IMainTransaction {
  block_identifier: IIdentifier,
  transaction: ITransaction
}

export interface IRossetaTransactionResponse {
  transactions: IMainTransaction[],
  total_count: number
}
