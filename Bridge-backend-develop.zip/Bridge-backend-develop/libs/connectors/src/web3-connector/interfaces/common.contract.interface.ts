import { EventData } from 'web3-eth-contract';
import { Web3ContractEventInterface } from '.';

export interface ContractEvents {}
