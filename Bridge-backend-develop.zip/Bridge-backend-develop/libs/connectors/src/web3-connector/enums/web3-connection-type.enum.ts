export enum Web3ConnectionTypeEnum {
  WSS = 'wss',
  HTTP = 'http',
  IPC = 'ipc',
}
