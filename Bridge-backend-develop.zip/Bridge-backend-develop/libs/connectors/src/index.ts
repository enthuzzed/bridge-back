export { Web3ConnectorModule } from './web3-connector/web3-connector.module';
export { PolygonBridgeContract } from './web3-connector/polygon-bridge.contract';
export { DfinityConnectorModule } from './dfinity-connector/dfinity-connector.module';
export { DfinityBridgeContract } from './dfinity-connector/dfinity-bridge.contract';
