export { DfinityConfigInterface } from './dfinity.connector.interface';
export { DfinityDidLoaderInterface } from './dfinity-did-loader.interface';
export * from './dfinity.interface';
