import { ActorSubclass } from '@dfinity/agent';

export interface DfinityConfigInterface {
  readonly url: string;
}
